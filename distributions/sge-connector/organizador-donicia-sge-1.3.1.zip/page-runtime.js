"use strict";
(() => {
  // src/sge-origin.mjs
  var sgeOrigins = ["https://www.sgebr.net.br", "https://www.sgebr.com.br"];
  function allowedSgeUrl(value2) {
    const url = new URL(value2);
    if (!sgeOrigins.includes(url.origin) || !url.pathname.startsWith("/sge8105/") || url.username || url.password) throw Error("Link fora do SGE.");
    return url.href;
  }

  // src/sge-pages.mjs
  var sgeBase = "https://www.sgebr.net.br/sge8105/";
  var value = (node, name) => {
    const field = node.querySelector('input[name="' + name + '"]');
    return (field?.value ?? field?.getAttribute("value") ?? "").trim();
  };
  var rowValue = (row, name) => [...row.querySelectorAll("input[name]")].find((x) => new RegExp("^" + name + "_\\d{4}$").test(x.name))?.getAttribute("value")?.trim() || "";
  var clean = (node) => node?.textContent.replace(/\s+/g, " ").trim() || "";
  var contextKeys = ["UECOD", "CURANO", "GRACOD", "TRNCOD", "SECNUM", "TURNUM"];
  var classKey = (row) => contextKeys.map((key) => rowValue(row, key)).join(":");
  function pageUrl(document2, url) {
    const form = document2.querySelector("#MAINFORM");
    if (!form) throw Error("P\xE1gina do SGE n\xE3o reconhecida. Fa\xE7a login e abra os planejamentos de turmas.");
    const action = form.getAttribute("action") || form.getAttribute("ACTION");
    const parsed = new URL(action || url, url || sgeBase);
    try {
      allowedSgeUrl(parsed.href);
      if (url && parsed.origin !== new URL(url).origin) throw Error();
    } catch {
      throw Error("Origem do SGE n\xE3o reconhecida.");
    }
    return parsed.href;
  }
  function navigation(document2) {
    const current = Number(value(document2, "_ATUAL") || 1), last = Number(value(document2, "_FINAL") || 1);
    if (!Number.isInteger(current) || !Number.isInteger(last) || current < 1 || last < current || last > 50) throw Error("Pagina\xE7\xE3o do SGE n\xE3o reconhecida.");
    return { current, last };
  }
  function parseSgeClasses(document2, url) {
    const sourceUrl = pageUrl(document2, url), grid = document2.querySelector("#GRIDTURMA");
    if (!grid) throw Error("Abra a lista de turmas de planejamento no SGE.");
    const classes = [...grid.querySelectorAll("tr")].filter((r) => r.querySelector('input[name^="TURNUM_"]')).map((row) => {
      const slot = row.querySelector('input[name^="TURNUM_"]').name.match(/_(\d{4})$/)[1], name = rowValue(row, "_WVAR") || rowValue(row, "TURCOD");
      if (!name || contextKeys.some((k) => !rowValue(row, k))) throw Error("Turma incompleta no SGE.");
      return { id: classKey(row), name, row: slot, url: sourceUrl };
    });
    if (classes.some((c) => !c.id.startsWith("106801:"))) throw Error("Lista de turmas de outra escola.");
    const pagination = navigation(document2), total = Number(value(document2, "_CONT") || classes.length);
    return { type: "classes", classes, sourceUrl, pagination, total, complete: pagination.last === 1 };
  }
  function parseSgeTeachers(document2, url) {
    const sourceUrl = pageUrl(document2, url), grid = document2.querySelector("#GRIDDISCIPLINA");
    if (!grid) throw Error("Disciplinas da turma n\xE3o encontradas.");
    const className = value(document2, "TURCOD"), teachers = [], assignments = /* @__PURE__ */ new Map();
    for (const row of grid.querySelectorAll("tr")) {
      const field = row.querySelector('input[name^="DISCOD_"]');
      if (!field) continue;
      const slot = field.name.match(/_(\d{4})$/)[1], subject = rowValue(row, "DISCODNOM");
      for (let position = 1; position <= 10; position++) {
        const name = rowValue(row, "_SERNOMPROF" + position), registration = rowValue(row, "_SERMATPROF" + position);
        if (!name) continue;
        if (!registration || registration === "0" || !subject) throw Error("Professor sem identifica\xE7\xE3o de matr\xEDcula no SGE.");
        const teacher = { id: "mat-" + registration, assignmentId: rowValue(row, "DISCOD") + ":" + registration, name, subject, row: slot, position, url: sourceUrl };
        const previous = assignments.get(teacher.assignmentId);
        if (previous && (previous.name !== name || previous.subject !== subject)) throw Error("V\xEDnculos incompat\xEDveis de professor e disciplina no SGE.");
        if (!previous) {
          assignments.set(teacher.assignmentId, teacher);
          teachers.push(teacher);
        }
      }
    }
    const pagination = navigation(document2);
    return { type: "teachers", className, classNumber: value(document2, "TURNUM"), grade: value(document2, "GRACOD"), stage: value(document2, "SECNUM"), teachers, sourceUrl, pagination, complete: pagination.last === 1 };
  }
  function brDate(text) {
    const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(text);
    if (!m) return null;
    const iso = m[3] + "-" + m[2] + "-" + m[1];
    return !Number.isNaN(Date.parse(iso)) && new Date(iso).toISOString().slice(0, 10) === iso ? iso : null;
  }
  var emptyPlans = (document2) => [...document2.querySelectorAll("span")].some((node) => clean(node) === "Professor(a) n\xE3o criou Planejamentos de Aula at\xE9 o momento");
  function parseSgePlans(document2, url) {
    const sourceUrl = pageUrl(document2, url), grid = document2.querySelector("#GRIDPLANEJADO");
    if (!grid && (!emptyPlans(document2) || !new URL(sourceUrl).pathname.toLowerCase().endsWith("/hplanejamentoaulager.aspx"))) throw Error("Planejamentos do professor n\xE3o encontrados.");
    const subject = value(document2, "DISCODNOM"), title = clean(document2.querySelector("#TITULO"));
    const prefix = "Planejamento de " + subject + " - ", teacherName = title.startsWith(prefix) ? title.slice(prefix.length) : "";
    if (!teacherName) throw Error("Nome do professor n\xE3o reconhecido na p\xE1gina de planejamentos.");
    const plans = [...grid?.querySelectorAll("tr") || []].filter((r) => r.querySelector('input[name^="PLAULASEQ_"]')).map((row) => {
      const slot = row.querySelector('input[name^="PLAULASEQ_"]').name.match(/_(\d{4})$/)[1];
      const start = brDate(rowValue(row, "PLAULADTINICIO")), end = brDate(rowValue(row, "PLAULADTFIM"));
      if (!start || !end || start > end) throw Error("Per\xEDodo do planejamento n\xE3o reconhecido.");
      return { id: rowValue(row, "PLAULASEQ"), title: rowValue(row, "_PERIODOPLANO"), start, end, lessons: Number(rowValue(row, "PLAULANUMAULAS")), includedAt: rowValue(row, "PLAULADATHORINC"), situation: row.querySelector('img[id^="_SITUACAO_"]')?.getAttribute("title")?.trim() || null, situationCode: rowValue(row, "PLAULASITUACAO"), trimester: null, row: slot, classId: classKey(row), subjectCode: rowValue(row, "DISCOD"), url: null };
    });
    const pagination = emptyPlans(document2) && plans.length === 0 ? { current: 1, last: 1 } : navigation(document2);
    return { type: "plans", teacherName, subject, plans, sourceUrl, pagination, complete: pagination.last === 1 };
  }
  function parseSgePage(document2, url) {
    if (document2.querySelector("#GRIDTURMA")) return parseSgeClasses(document2, url);
    if (document2.querySelector("#GRIDDISCIPLINA")) return parseSgeTeachers(document2, url);
    if (document2.querySelector("#GRIDPLANEJADO") || emptyPlans(document2)) return parseSgePlans(document2, url);
    return { type: "detail", sourceUrl: pageUrl(document2, url) };
  }

  // sge-connector/page-runtime.mjs
  window.__doniciaSge = {
    snapshot() {
      return parseSgePage(document, location.href);
    },
    open(action) {
      const snapshot = parseSgePage(document, location.href);
      let element;
      if (action.kind === "next" || action.kind === "first") {
        const name = action.kind === "next" ? "BTN_PROXIMO" : "BTN_PRIMEIRO";
        element = document.querySelector('input[name="' + name + '1"]') || document.querySelector('input[name="' + name + '"]');
      } else if (action.kind === "class" && snapshot.type === "classes") {
        const c = snapshot.classes.find((c2) => c2.id === action.id);
        if (c) element = document.querySelector("#span__WVAR_" + c.row + " a");
      } else if (action.kind === "teacher" && snapshot.type === "teachers") {
        const t = snapshot.teachers.find((t2) => t2.assignmentId === action.id);
        if (t) element = document.querySelector("#span__SERNOMPROF" + t.position + "_" + t.row + " a");
      } else if (action.kind === "plan" && snapshot.type === "plans") {
        const p = snapshot.plans.find((p2) => p2.id === action.id);
        if (p) element = document.querySelector("#span__PERIODOPLANO_" + p.row + " a");
      }
      if (!element || element.disabled) throw Error("A\xE7\xE3o de consulta n\xE3o encontrada no SGE.");
      const code = element.getAttribute("href") || element.getAttribute("onclick") || "";
      const expected = action.kind === "next" ? "BTN_PROXIMO" : action.kind === "first" ? "BTN_PRIMEIRO" : action.kind === "class" ? "CONSULTA" : action.kind === "teacher" ? "PLANOPROF" : "CONSULTARPLANEJAMENTO";
      if (!code.includes(expected) || /ALTERAR|PLANOANALISAR|EXCLUIR|SALVAR|GRAVAR/.test(code)) throw Error("Esta a\xE7\xE3o n\xE3o \xE9 uma consulta permitida.");
      element.click();
      return true;
    }
  };
})();
