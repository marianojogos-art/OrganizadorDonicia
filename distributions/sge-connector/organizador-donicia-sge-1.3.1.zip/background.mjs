// src/sge-origin.mjs
var sgeOrigins = ["https://www.sgebr.net.br", "https://www.sgebr.com.br"];
function allowedSgeUrl(value) {
  let url = new URL(value);
  if (!sgeOrigins.includes(url.origin) || !url.pathname.startsWith("/sge8105/") || url.username || url.password) throw Error("Link fora do SGE.");
  return url.href;
}

// src/supervision.mjs
var SupervisionError = class extends Error {
  constructor(message, status = 502) {
    super(message), this.status = status;
  }
};
function planningTrimester(start, end) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(start) || !/^\d{4}-\d{2}-\d{2}$/.test(end) || start > end || Number.isNaN(Date.parse(start)) || Number.isNaN(Date.parse(end)) || new Date(start).toISOString().slice(0, 10) !== start || new Date(end).toISOString().slice(0, 10) !== end) throw new SupervisionError("Datas do planejamento inv\xE1lidas.");
  if (start.slice(0, 4) !== end.slice(0, 4)) return null;
  let ranges = [["03-01", "05-31"], ["06-01", "09-30"], ["10-01", "12-31"]], year = start.slice(0, 4), index = ranges.findIndex(([from, to]) => start >= year + "-" + from && end <= year + "-" + to);
  return index < 0 ? null : index + 1;
}

// src/sge-reader.mjs
var normalize = (s) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
function createSgeReader(transport) {
  async function directory(progress = () => {
  }) {
    let page = await transport.snapshot();
    if (page.type !== "classes") throw Error("Abra a p\xE1gina 1 (lista de turmas dos planejamentos) em uma aba do SGE.");
    page.pagination.current !== 1 && (page = await transport.move({ kind: "first" }));
    let firstPageIds = page.classes.map((c) => c.id), sourceUrl = page.sourceUrl, total = page.total, classes = [];
    for (let index = 1; index <= page.pagination.last; index++) {
      if (page.type !== "classes" || page.pagination.current !== index) throw Error("A pagina\xE7\xE3o de turmas mudou no SGE.");
      await progress({ stage: "directory", current: index, total: page.pagination.last, classCount: classes.length + page.classes.length, schoolTotal: total }), classes.push(...page.classes), index < page.pagination.last && (page = await transport.move({ kind: "next" }));
    }
    if (classes.length !== total || new Set(classes.map((c) => c.id)).size !== classes.length) throw Error("A lista completa de turmas n\xE3o confere com o total do SGE.");
    return { classes, firstPageIds, sourceUrl, complete: !0 };
  }
  async function locateClass(source, id) {
    let page = await transport.navigate(source);
    if (page.type !== "classes") throw Error("N\xE3o foi poss\xEDvel voltar \xE0 lista de turmas.");
    page.pagination.current !== 1 && (page = await transport.move({ kind: "first" }));
    for (let index = 1; index <= page.pagination.last; index++) {
      if (page.classes.some((c) => c.id === id)) return await transport.move({ kind: "class", id });
      index < page.pagination.last && (page = await transport.move({ kind: "next" }));
    }
    throw Error("A turma n\xE3o aparece mais na lista do SGE.");
  }
  function matchesClass(teachers, classId) {
    let key = classId.split(":");
    return teachers.type === "teachers" && teachers.complete && teachers.classNumber === key[5] && teachers.grade === key[2] && teachers.stage === key[4];
  }
  async function readClass(input) {
    if (typeof input?.classId != "string" || !/^106801:\d{4}:\d+:\d+:\d+:\d+$/.test(input.classId)) throw Error("Turma inv\xE1lida.");
    let teachers = await locateClass(allowedSgeUrl(input.sourceUrl), input.classId);
    if (!matchesClass(teachers, input.classId)) throw Error("P\xE1gina de disciplinas n\xE3o corresponde \xE0 turma confirmada.");
    return { ...teachers, classId: input.classId };
  }
  async function readPlanning(input, progress = () => {
  }) {
    if (typeof input?.classId != "string" || typeof input.assignmentId != "string") throw Error("Professor ou turma inv\xE1lidos.");
    let teachers = await transport.navigate(allowedSgeUrl(input.sourceUrl));
    if (!matchesClass(teachers, input.classId)) throw Error("N\xE3o foi poss\xEDvel voltar aos professores da turma confirmada.");
    let t = teachers.teachers.find((t2) => t2.assignmentId === input.assignmentId);
    if (!t) throw Error("O professor mudou. Consulte as turmas novamente.");
    let page = await transport.move({ kind: "teacher", id: t.assignmentId });
    if (page.type !== "plans" || !page.complete || page.plans.some((p) => p.classId !== input.classId || p.subjectCode !== t.assignmentId.split(":")[0]) || !normalize(page.teacherName).startsWith(normalize(t.name))) throw Error("P\xE1gina de planejamentos n\xE3o corresponde ao professor e \xE0 turma.");
    if (![void 0, "", 1, 2, 3].includes(input.trimester)) throw Error("Escolha um trimestre v\xE1lido.");
    let plans = page.plans.map((p) => ({ ...p, trimester: p.start && p.end ? planningTrimester(p.start, p.end) : p.trimester })).filter((p) => !input.trimester || p.trimester === input.trimester), name = page.teacherName, sourceUrl = page.sourceUrl;
    if (input.query && !normalize(name).includes(normalize(input.query))) return { classId: input.classId, teacherId: t.id, assignmentId: t.assignmentId, name, sourceUrl, complete: !0, plans: [] };
    await progress({ stage: "planning-list", name, total: plans.length });
    for (let index = 0; index < plans.length; index++) {
      let plan = plans[index];
      if (Array.isArray(input.preservePlanIds) && input.preservePlanIds.includes(plan.id)) continue;
      await progress({ stage: "opening-plan", name, current: index + 1, total: plans.length, title: plan.title, situation: plan.situation });
      try {
        if (page = await transport.navigate(sourceUrl), page.type !== "plans") throw Error("P\xE1gina de planejamentos indispon\xEDvel.");
        let detail = await transport.move({ kind: "plan", id: plan.id });
        if (detail.type !== "detail" || new URL(detail.sourceUrl).pathname === new URL(sourceUrl).pathname) throw Error("O SGE n\xE3o retornou um endere\xE7o direto para este planejamento.");
        plan.url = detail.sourceUrl;
      } catch (e) {
        plan.url = null, plan.linkError = e.message;
      }
      let { id, title, start, end, trimester, situation, url } = plan;
      await progress({ stage: "plan-read", name, current: index + 1, total: plans.length, sourceUrl, plan: { id, title, start, end, trimester, situation, url } });
    }
    return { classId: input.classId, teacherId: t.id, assignmentId: t.assignmentId, name, sourceUrl, complete: !0, plans };
  }
  return { directory, teachers: readClass, planning: readPlanning };
}

// sge-connector/background.mjs
var organizerOrigins = /* @__PURE__ */ new Set(["https://organizadordonicia.carijo.workers.dev"]), running = !1;
function completed(tabId) {
  let timer, listener, promise = new Promise((resolve, reject) => {
    listener = async (id, change) => {
      if (!(id !== tabId || change.status !== "complete"))
        try {
          let tab = await chrome.tabs.get(tabId);
          if (tab.status !== "complete" || tab.pendingUrl || !tab.url || tab.url === "about:blank") return;
          try {
            allowedSgeUrl(tab.url);
          } catch {
            throw Error("A aba de consulta saiu do SGE. Entre novamente no SGE e tente outra vez.");
          }
          cleanup(), resolve();
        } catch (e) {
          cleanup(), reject(e);
        }
    }, timer = setTimeout(() => {
      cleanup(), reject(Error("A p\xE1gina do SGE demorou a abrir. Verifique sua sess\xE3o e tente novamente."));
    }, 25e3), chrome.tabs.onUpdated.addListener(listener);
  }), cleanup = () => {
    clearTimeout(timer), chrome.tabs.onUpdated.removeListener(listener);
  };
  return promise.catch(() => {
  }), { promise, cancel() {
    cleanup();
  } };
}
async function snapshot(tabId) {
  let tab = await chrome.tabs.get(tabId);
  if (tab.status !== "complete" || tab.pendingUrl || !tab.url || tab.url === "about:blank") throw Error("A aba tempor\xE1ria ainda n\xE3o terminou de abrir o SGE. Tente novamente.");
  try {
    allowedSgeUrl(tab.url);
  } catch {
    throw Error("A aba de consulta saiu do SGE. Entre novamente no SGE e tente outra vez.");
  }
  await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", files: ["page-runtime.js"] });
  let result = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: () => {
    try {
      return window.__doniciaSge.snapshot();
    } catch (e) {
      return { readError: e.message };
    }
  } });
  if (result[0]?.result?.readError) throw Error(result[0].result.readError);
  if (!result[0]?.result) throw Error("N\xE3o foi poss\xEDvel ler a p\xE1gina do SGE. Verifique se a sess\xE3o est\xE1 autenticada.");
  return result[0].result;
}
async function move(tabId, action) {
  let wait = completed(tabId);
  try {
    return await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: (action2) => window.__doniciaSge.open(action2), args: [action] }), await wait.promise, await snapshot(tabId);
  } catch (e) {
    throw wait.cancel(), e;
  }
}
async function navigate(tabId, url) {
  let wait = completed(tabId);
  try {
    return await chrome.tabs.update(tabId, { url: allowedSgeUrl(url) }), await wait.promise, await snapshot(tabId);
  } catch (e) {
    throw wait.cancel(), e;
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  let origin;
  try {
    origin = new URL(sender.url).origin;
  } catch {
    return !1;
  }
  return organizerOrigins.has(origin) ? message.command === "ping" ? (sendResponse({ ok: !0, data: { version: "1.3.1", progress: !0, selective: !0 } }), !1) : ["directory", "teachers", "planning"].includes(message.command) ? running ? (sendResponse({ error: "J\xE1 h\xE1 uma consulta ao SGE em andamento. Aguarde." }), !1) : (running = !0, (async () => {
    let tabId;
    try {
      let source = (await chrome.tabs.query({ url: sgeOrigins.map((origin2) => origin2 + "/sge8105/*") })).find((t) => new URL(t.url).pathname.toLowerCase().endsWith("/hselgerenciamentoplanoaula.aspx"));
      if (!source) throw Error("Entre no SGE e deixe aberta a p\xE1gina 1, com a lista de turmas dos planejamentos.");
      tabId = (await chrome.tabs.create({ url: "about:blank", active: !1 })).id, await navigate(tabId, source.url);
      let progress = async (update) => {
        sender.tab?.id && typeof message.id == "string" && await chrome.tabs.sendMessage(sender.tab.id, { channel: "donicia-sge-progress", id: message.id, progress: update }).catch(() => {
        });
      }, reader = createSgeReader({ snapshot: () => snapshot(tabId), navigate: (url) => navigate(tabId, url), move: (action) => move(tabId, action) }), data = message.command === "directory" ? await reader.directory(progress) : message.command === "teachers" ? await reader.teachers(message.input) : await reader.planning(message.input, progress);
      await chrome.tabs.remove(tabId).catch(() => {
      }), tabId = null, running = !1, sendResponse({ data });
    } catch (e) {
      tabId && await chrome.tabs.remove(tabId).catch(() => {
      }), tabId = null, running = !1, sendResponse({ error: e.message });
    } finally {
      tabId && await chrome.tabs.remove(tabId).catch(() => {
      }), running = !1;
    }
  })(), !0) : !1 : !1;
});
